## Your Turn Excercise 1

# read in the data included to the website using `read.csv` and assign it to the object named penguins
  <-  read.csv()
# What happens when you do not assign the dataset?
  read.csv()

# use `View`, `head`, and `tail` to inspect the dataset hint you need to supply them a name

# using `install.packages()` install ggplot2



## Your Turn Excercise 2

# Find the minimum value of `bill_length_mm`

# Find the maximum value of `body_mass_g`#

# Find the range of bill_length or body_mass

# Subset the penguins data any way you want using `[]` or `$`#

# Assign each of them to an object

# Create a vector of anything you want and find the second thing in that vector using `[]`#

# Do the same thing using `$`